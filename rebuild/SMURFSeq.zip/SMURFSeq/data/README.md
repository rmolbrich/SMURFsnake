# SMURFSeq genome segments

## hg19-bins

These files were obtained from the original [SMURFSeq GitHub](https://github.com/smithlabcode/smurfseq_scripts) page. The Procedure for bin-generation is outlined there.


## hg38-bins

These are the result of a quick and dirty lift-over procedure of the original hg19-bins.